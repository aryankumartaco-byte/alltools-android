ALLTOOLS — build an APK using only your Android phone

You do NOT need Android Studio. GitHub Actions builds the APK on GitHub's cloud computers.

FILES
1. ALLTOOLS_ANDROID_SOURCE.zip — your Android source project (upload this file to your GitHub repository root).
2. .github/workflows/build-apk.yml — the workflow file. Create this exact path in your GitHub repository and paste its contents.

PHONE STEPS
1. Sign in to https://github.com/ in Chrome. Create a new repository named alltools-android. A private repository is fine. GitHub Mobile can also create a repository.
2. Open the repository in Chrome. Choose Add file > Upload files. Upload ALLTOOLS_ANDROID_SOURCE.zip to the repository root and commit it.
3. In the repository, choose Add file > Create new file.
4. In the filename box enter exactly: .github/workflows/build-apk.yml
5. Open the supplied build-apk.yml file from this pack, copy all its contents, paste them into GitHub's editor, then commit the new file to the main branch.
6. Open the repository's Actions tab. Select “Build ALLTOOLS Android APK”. Press Run workflow > Run workflow.
7. Wait for the workflow to finish. Open the completed run. Under Artifacts, tap ALLTOOLS-debug-APK to download the APK zip.
8. Open the downloaded artifact ZIP in your phone's Files app and extract it. Tap the APK to install. If Android asks, allow Chrome/Files to install unknown apps for this installation, then install. You can turn that permission off afterwards.

IF THE WORKFLOW DOES NOT START
- Confirm the workflow file path is exactly .github/workflows/build-apk.yml.
- Confirm ALLTOOLS_ANDROID_SOURCE.zip is at the repository root, not inside another folder.
- In Actions, enable workflows if GitHub asks you to enable them.
- Open the failed run and check the first red step. Share the error text for help.

IMPORTANT
- This creates a DEBUG APK for private testing. It is not the signed Play Store release.
- Do not upload private signing keys, passwords, Aadhaar PDFs, or real user documents to GitHub.
- Keep the repository private if you do not want the source code publicly visible.
- This workflow compiles the supplied source; it does not add missing advanced features. Aadhaar cryptographic validation, OCR and some advanced converters still need implementation and testing.
- For Play Store, a separate release workflow and a private upload keystore are required. Never commit the keystore or passwords to the repository.
