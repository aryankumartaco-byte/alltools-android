# ALLTOOLS pre-release privacy and originality checklist

- Use original ALLTOOLS name/logo/UI and independently written code; trademark clearance is still required.
- Maintain a dependency inventory with exact versions, licences, notices and security review.
- Keep copies of licences for icons, fonts, images and all bundled libraries.
- No competitor logos, screenshots, text, proprietary code or confusingly similar UI assets.
- No UIDAI/government affiliation claim; clearly describe signature verification scope and limitations.
- Do not claim Aadhaar signature validation until certificate chain, trust anchors, signing-time semantics and revocation checks are genuinely implemented and tested.
- Keep user files local; do not log filenames, contents, Aadhaar numbers or OCR output.
- Request camera only when needed; use Android system picker for documents.
- Add accurate privacy policy, terms, support contact and advertising disclosure before launch.
