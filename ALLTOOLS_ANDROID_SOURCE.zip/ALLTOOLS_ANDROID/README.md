# ALLTOOLS Android + Website starter

Original, lightweight ALLTOOLS web app bundled inside a native Android WebView shell. The Android shell adds Android document picker support and camera permission handling for the browser-based scanner.

## What's included

- `app/src/main/assets/public/`: current ALLTOOLS browser-first website/PWA files.
- `app/src/main/java/com/alltools/app/MainActivity.kt`: Android WebView, local asset loading, Android file picker and camera permission bridge.
- Gradle Android project files for Android Studio.
- Application ID: `com.alltools.app`.
- Minimum Android version: Android 7.0 (API 24).

## Build a debug APK

1. Install the latest stable Android Studio and Android SDK Platform 35.
2. Open this folder (`ALLTOOLS_ANDROID`) in Android Studio.
3. Allow Gradle sync and dependency downloads. This project uses Android Gradle Plugin 8.7.3, Kotlin 2.0.21, AndroidX WebKit and Material Components.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio creates the debug APK under `app/build/outputs/apk/debug/`.
6. Install on a test phone and verify camera capture, file import, all exports, back navigation, offline start and memory use.

## Create Play Store AAB

1. In Android Studio choose **Build → Generate Signed Bundle / APK**.
2. Choose **Android App Bundle**.
3. Create and securely back up your own upload keystore. Never share it or commit it to source control.
4. Use a unique final application ID if you decide to change `com.alltools.app`; changing it after publishing creates a different app listing.
5. Generate a signed release AAB and test it through Play Console internal testing before production.

## Browser-only processing and honest limitations

The website code runs inside Android WebView. Core tools already present in the bundled site include multi-page camera scanning, image compression/resize/conversion, images-to-PDF, ID-card layout, text-to-PDF, PDF merge/page extraction/rotation, ZIP create/extract and QR generation. Some optional libraries are fetched on first use, so those specific tools need internet until their dependency is cached. The initial shell is local.

The app does **not** yet implement every feature in the full ALLTOOLS roadmap. OCR, robust document edge detection/perspective correction, advanced Office conversions, PDF compression/editing/redaction and genuine cryptographic Aadhaar/PDF signature validation remain unimplemented. The signature screen explicitly says it cannot verify cryptographically. Do not advertise these as working until built and tested.

Blob download/export behaviour varies by Android WebView version. Test every export on real devices. If any Blob URL export fails, implement a narrowly scoped, reviewed Android JavaScript bridge to save bytes via Android's Storage Access Framework; do not grant broad filesystem access.

## Privacy and permissions

- Camera permission is requested only when the scanner is used.
- File access uses Android's system document picker; no broad storage permission is requested.
- No server upload endpoint or user account is included in this edition.
- Do not add analytics or ad SDKs that collect filenames, document contents, Aadhaar data or OCR text.
- If ads are introduced, use a privacy-reviewed provider and disclose data practices. Ads must never receive file data.

## Before public release

- Test on low-memory Android phones and slow connections.
- Self-host and pin optional JS dependencies after licence/security review; the current web app loads some optional libraries from CDNs on demand.
- Add original privacy policy, terms, support contact and ad disclosures.
- Complete Google Play Data safety form and app content declarations accurately.
- Review target API requirements and Play policies at release time.
- Perform dependency, licence, trademark, accessibility and security reviews.
- Configure app signing, versioning, crash handling without sensitive data, and release testing.

This is an Android Studio source project, not a precompiled APK/AAB. A signed installable package requires Android SDK/Gradle build tools and the developer's private signing key.
