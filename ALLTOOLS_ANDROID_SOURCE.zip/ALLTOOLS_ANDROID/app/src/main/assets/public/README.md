# ALLTOOLS — lightweight browser-first PWA

A mobile-first, installable static web app. Core UI and app shell are small and cacheable. File operations run in the browser; optional processing libraries are loaded only when a tool is opened. No upload API or server-side file storage is included.

## Run locally

Because camera access and service workers require a secure context, run through localhost rather than opening `index.html` as a file:

```bash
python3 -m http.server 8080
```

Open `http://localhost:8080`.

## Free static hosting

Deploy the contents of this folder to GitHub Pages, Cloudflare Pages, or Netlify's free static tier. Use the folder root as the publish directory. Configure HTTPS (provided by these hosts). No backend, database, account system, or upload bucket is required for this browser-only edition.

## Browser tools currently implemented

- Multi-page camera scanner (capture, import images, reorder/remove pages, colour/grayscale/black-and-white filter, PDF export).
- Image compression with custom target size, quality control, before/after preview, achieved size and download.
- Image resize and JPG/PNG/WebP conversion.
- Images to PDF, ID-card front/back A4 layout, text to PDF.
- PDF merge, page extraction by page ranges, rotate all pages.
- ZIP create/extract (optional JSZip library).
- QR code generation (optional QRCode library).
- Aadhaar/general PDF signature upload-and-inspection screen which explicitly reports that cryptographic validation is unavailable. It does not fake a valid/invalid result.

## Visible but not implemented

PDF compression, robust PDF-to-image rendering, PDF editing, password encryption/decryption, redaction, OCR, handwriting recognition, AI summaries, DOCX/XLSX/PPTX conversions, advanced scanner edge detection/perspective correction, background removal, and cryptographic PDF signature verification. These are marked planned/engine-required in the UI and are not advertised as working.

## Important limitations

- Exact target file size is best-effort. Some formats cannot reach a requested size without unacceptable quality loss. The tool displays actual output size.
- Browser support depends on the device and browser. Camera requires HTTPS/localhost and user permission.
- Optional libraries are fetched from public CDNs when needed. The shell can load offline after it has been cached, but optional tools may require internet on first use. For strict offline deployment, vendor audited library builds locally and update the service-worker asset list.
- This build has no server. Therefore it cannot reliably retrieve certificate revocation status, maintain UIDAI/CCA trust roots, or validate Aadhaar/PDF signatures cryptographically. Never treat the signature screen as a validation result. A real verifier requires a maintained trust store and validation implementation, or a trusted verification provider; that requirement conflicts with a strictly browser-only/offline architecture unless the trust data and cryptographic implementation are maintained in the client.
- No server-side OCR or AI is included. Client-side OCR would require downloading sizeable language data, which conflicts with the low-bandwidth objective; make it optional and download language packs on demand if added later.
- Do not upload Aadhaar or other identity documents to an untrusted website. Use only documents you are authorised to process.

## Recommended architecture

1. Static PWA shell: HTML, CSS, small vanilla JS, manifest and service worker.
2. Feature modules: load each optional engine only on user action; use Web Workers for CPU-heavy work to keep the interface responsive.
3. Local file lifecycle: File API → validation → worker/canvas processing → Blob preview → download; revoke object URLs when previews are replaced/closed.
4. No tracking of filenames, document content, Aadhaar numbers, or upload activity. Ads, if added, must be separated from file inputs and never receive file data.
5. Quality gates before launch: test mobile Safari/Chrome, low-memory Android devices, large files, corrupted/encrypted PDFs, offline refresh, camera permission denial, keyboard navigation, and screen-reader labels.

## Security and production checklist

- Pin and self-host audited dependency versions; do not rely on unpinned CDN `latest` URLs.
- Add a strict Content Security Policy and security headers at the hosting provider.
- Add file-size limits and graceful memory handling; browser memory is finite.
- Never render user-provided filenames/metadata as HTML; escape all displayed text.
- Add automated unit/integration tests and independent security review before claiming production readiness.
- Add privacy policy, terms, contact details, accessibility statement, and ad disclosure before monetisation.
- Verify licensing and trademark permissions for all dependencies and branding.

This is a functional first implementation, not a claim that every listed competitor feature is already implemented or independently security-audited.
